<?php

$conexion=mysqli_connect('localhost', 'miguel', 'miguel','INVENTARIO');
    mysqli_set_charset($conexion,"utf8");
    

    $marca = mysqli_real_escape_string($conexion, $_POST['marca']);
    $modelo = mysqli_real_escape_string($conexion, $_POST['modelo']);
    $precio = mysqli_real_escape_string($conexion, $_POST['precio']);
    $enstock = mysqli_real_escape_string($conexion, $_POST['En_Stock']);

    $sql = "INSERT INTO PRODUCTOS (Marca, Modelo, Precio, En_Stock) VALUES ('$marca', '$modelo', '$precio','$enstock')";
if(mysqli_query($conexion, $sql));
 

?>

<!DOCTYPE html>
<html lang="en">
<head>
  
    <meta charset="UTF-8">
   
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Techno Market: Insertar Datos</title>
   
    <link rel="stylesheet" href="IMAGENES/">
       
    <link rel="stylesheet" href="CSS/Insertdatos.css">
        
    <link rel="stylesheet" href="iconos/css/fontello.css">

    <header>
        <img src="IMAGENES/LOGOMIGUEL.png" class="img-logo">
        
        <input type="checkbox" id="check">
            <label for="check" class="icon-menu"></label>
            <nav class="menu">
                <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="productos.php">Productos</a></li>
                <li><a href="insertardatos.php" style="background:#1e1e1e;color:white;">Inserte</a></li>
                <li><a href="buscar.php">Busqueda</a></li>

            </ul>
            </nav>
        </header>
        <img src="IMAGENES/BANNER.png" class="banner">
</head>

<body>

<div id="formulario">
<form method="POST">

    
    <label for="MARCA">Marca:</label>
    
    <input type="text" id="MARCA" name="marca">

    <label for="MODELO"> Modelo:</label>

    <input type="text" id="MODELO" name="modelo" >

    <label for="PRECIO">Precio:</label> 

    <input type="text" id="PRECIO" name="precio" >

    <label for="EN_STOCK">En Stock:</label>

    <input type="text" id="EN_STOCK" name="En_Stock">

    <input type="submit" id="BUSCAR" value="Enviar">






    </form>
</div>

</body>
</html>

