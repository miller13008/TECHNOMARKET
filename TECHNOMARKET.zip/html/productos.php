<?php  
    $conexion=mysqli_connect('localhost', 'miguel', 'miguel','INVENTARIO');
    mysqli_set_charset($conexion,"utf8");

?> 

<!DOCTYPE html>
<html>
    <head>
    
    <title>Techno Market: Productos</title>
    <meta charset="utf-8">
    
        <link rel="stylesheet" href="IMAGENES/">
        <link rel="stylesheet" href="CSS/productos.css">
        <link rel="stylesheet" href="iconos/css/fontello.css">
        
    </head>
    
  <body>
 
        <header>
            <img src="IMAGENES/LOGOMIGUEL.png" class="img-logo">
            <input type="checkbox" id="check">
            <label for="check" class="icon-menu"></label>
            <nav class="menu">
                <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="productos.php" style="background:#1e1e1e;color:white;">Productos</a></li>
                <li><a href="insertardatos.php">Inserte</a></li>
                <li><a href="buscar.php">Busqueda</a></li>

                </ul>
            </nav>
        </header>
        <br>
        <table class="tabla" >
            <tr class="titulotabla">
                <th>Marca</th>
                <th>Modelo</th>
                <th>Precio</th>
                <th>En Stock</th>
            </tr>


            
            <?php
            $sql="SELECT * from PRODUCTOS";
            $result= mysqli_query($conexion,$sql);
            while($mostrar=mysqli_fetch_array($result)) {
            ?>
            <tr class="dentrotabla">
                <td><?php echo $mostrar['marca']?></td>
                <td><?php echo $mostrar['modelo']?></td>
                <td><?php echo $mostrar['precio']?></td>
                <td><?php echo $mostrar['En_Stock']?></td>
            </tr>
            <?php
            }
            ?>

        </table>    

    </body> 
    
</html>