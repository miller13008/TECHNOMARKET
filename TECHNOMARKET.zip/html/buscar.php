<?php
 $db_host="localhost";
 $db_usuario="miguel";
 $db_contra="miguel";
 $db_nombre="INVENTARIO";
 $conexion=new mysqli($db_host,$db_usuario,$db_contra);
 mysqli_set_charset($conexion,"utf8");
 ?>





<!DOCTYPE html>
<html>
<head>
<title>Techno Market: Productos</title>
    <meta charset="utf-8">
    
        <link rel="stylesheet" href="IMAGENES/">
        <link rel="stylesheet" href="CSS/buscar.css">
        <link rel="stylesheet" href="iconos/css/fontello.css">
</head>
<body>
<header>
            <img src="IMAGENES/LOGOMIGUEL.png" class="img-logo">
            <input type="checkbox" id="check">
            <label for="check" class="icon-menu"></label>
            <nav class="menu">
                
                <ul> 
                <form method="POST">
  <input type="text" name="marca" placeholder="Ingrese codigo a buscar">
  <input type="submit" name="buscar" value="Buscar">
 </form>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="productos.php">Productos</a></li>
                <li><a href="insertardatos.php">Inserte</a></li>
                <li><a href="buscar.php" style="background:#1e1e1e;color:white;">Busqueda</a></li>
             
                </ul>
            </nav>
            <form method="POST">

        </header>








<br>
    <table class="tabla2">
        <tr class="titulotabla2">
            <th>Marca</th>
            <th>Modelo</th>
            <th>Precio</th>
            <th>En Stock</th>
        </tr>

        

        <?php
        $marca=$_POST['marca'];
        mysqli_select_db($conexion,$db_nombre) or die("Error al conectar con la base de datos");
        $registros=$conexion->query("SELECT * FROM PRODUCTOS WHERE marca='$marca'");
        
         while($registro=$registros->fetch_assoc()){
        ?>
        <tr class="dentrotabla2">
            <td><?php echo $registro['marca']?></td>
            <td><?php echo $registro['modelo']?></td>
            <td><?php echo $registro['precio']?></td>
            <td><?php echo $registro['En_Stock']?></td>
        </tr>
        <?php
        }
        ?>

    </table>

</body>

</html>